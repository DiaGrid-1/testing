var APP_DATA = {
  "scenes": [
    {
      "id": "0-stewart_house-1",
      "name": "Stewart_House-1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1350,
      "initialViewParameters": {
        "yaw": -0.288988087795758,
        "pitch": 0.12400482383430855,
        "fov": 1.2820191017947098
      },
      "linkHotspots": [
        {
          "yaw": -0.538190541170934,
          "pitch": 0.03993163824795154,
          "rotation": 0,
          "target": "2-stewart_house-8"
        },
        {
          "yaw": 0.7434356618291549,
          "pitch": 0.11585748658573713,
          "rotation": 0,
          "target": "1-stewart_house-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-stewart_house-2",
      "name": "Stewart_House-2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1350,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "2-stewart_house-8",
      "name": "Stewart_House-8",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1350,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Test virtual tour",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
